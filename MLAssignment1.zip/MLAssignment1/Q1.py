import numpy as np
Vec1=np.random.rand(100)
Vec1_sorted = np.sort(Vec1)
print("sorted vector Vec1:")
print(Vec1_sorted)
