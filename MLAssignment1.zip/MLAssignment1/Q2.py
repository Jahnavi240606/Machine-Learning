import numpy as np
V1= np.random.rand(100)
V1_scaled = V1 * 3
print("Original vector V1:")
print(V1)
print("\n Scaled Vector V1 (V1 * 3): ")
print(V1_scaled)
