
import numpy as np
V1 = np.random.rand(100)
mean_V1 = np.mean(V1)
std_dev_V1 = np.std(V1)
print("Vector (V1): ")
print(V1)
print(f"\n Mean of V1: {mean_V1}")
print(f"Standard Deviation of V1: {std_dev_V1}")
