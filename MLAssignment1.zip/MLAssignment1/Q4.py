import numpy as np

mat = np.random.random((4, 3))
flat_array = mat.ravel()
print("Original Matrix (4x3):")
print(mat)
print("\nSingle Dimensional Array:")
print(flat_array)
