S1 = "I am a great learner. I am going to have an awesome life. "
Occurrence_count = S1.count("Am")
print(f"string (S1) : {S1}")
print(f"\nThe Occurrence count of 'Am' in the string : {Occurrence_count}")
