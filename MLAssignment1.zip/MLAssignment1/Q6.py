S1 = "I am a great learner. I am going to have an awesome life. "
S2 = "I work hard and shall be rewarded well."
S3 = S1 + " " + S2
print("String S1: ")
print(S1)
print("\nString S2:")
print(S2)
print("\nCombined String (S3):")
print(S3)
